# ia32emudll
is an emulator for execute up to x86_32 ring 0 on the windows and/or hsp3 program which based neko cpu from np21w!

Module CODENAME:Blåhaj
